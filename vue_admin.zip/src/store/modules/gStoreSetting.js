export default {
  namespaced:true,
  state:{
    name:'gStoreSetting',
  },
  mutations:{
    getname(state) {
      console.log(state.name);
    }
  },
  actions:{

  }
}
